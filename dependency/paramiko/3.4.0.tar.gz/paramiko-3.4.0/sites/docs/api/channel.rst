Channel
=======

.. automodule:: paramiko.channel
