.. include:: ../../plugins/sqlite/README
